
/*
- SÁNCHEZ ALANIS JOSÉ ANTONIO
*/

package Codigo;
public enum Tokens {
    OPER_ARITMETICO,
    OPER_LOGICO,
    OPER_RELACIONAL,
    OPER_BOOL,
    OPER_ASIGNACION,
    OPERADOR,
    SALTO_LINEA,
    RESERVADA,
    VARIABLE,
    IDENTIFICADOR,
    NUM_ENTERO,
    NUM_FLOAT,
    NUM_IMAG,
    STRING,
    TABULACION,
    ERROR
}
